<?php
/**
 * @SuppressWarnings(PHPMD)
 * @codingStandardsIgnoreFile
 */

define('PUBLIC_DIR', __DIR__);
require_once __DIR__.'/../vendor/oro/marketing/src/Oro/Bundle/TrackingBundle/tracking.php';
