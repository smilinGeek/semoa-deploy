UPGRADE FROM 1.10 to 2.0 
========================

## app/config/config.yml
- removed `be_simple_soap` section.
- removed `authentication_listener_class` parameter from `escape_wsse_authentication` section
